import UIKit
class A {
    var b: B
    init(b: B) {
    self.b = b
    }
    deinit {
        print("A")
    }
}
class B {
    weak var a: A?
    deinit {
        print("B")
    }
}
func test() {
    var b:B? = B()
    let a: A? = A(b: b!)
    b?.a = a
    b = nil
}
// What is the output
//Given Ans: AB

print(test())
//1. B
//2. BA
//3. AB
//4. None of the above
// actual answer None of the above
// Because a is still in scope and not nit, the instance of A is strongly referenced.
// In turn, it holds a strong reference to the instance of B.
// Only once we set a to nil are both objects deinited.

