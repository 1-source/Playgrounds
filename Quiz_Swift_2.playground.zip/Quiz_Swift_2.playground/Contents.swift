import UIKit

final class R { }

struct X {
    var ref = R()
    mutating func change() -> String {
        return isKnownUniquelyReferenced(&ref) ? "No copy" : "Copy"
        
    }
}

let x = X()
var array = [x]
let result = array[0].change()
print(result)
